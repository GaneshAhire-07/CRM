// import React, { useState } from "react";
// import "./FilterClients.css";
// import { LuFilter } from "react-icons/lu";
// import { IoCloseSharp } from "react-icons/io5";

// const FilterClientsModal = ({ onClose, onApply, onReset }) => {
//   const [filters, setFilters] = useState({
//     company: "",
//     category: "",
//     tags: "",
//     startDate: "",
//     endDate: "",
//     status: "",
//     vat: "",
//     projectType: "",
//   });

  

//   const handleChange = (e) => {
//     setFilters({
//       ...filters,
//       [e.target.name]: e.target.value,
//     });
//   };

//   const handleApply = () => {
//     onApply(filters);
//     onClose();
//   };

//   const handleReset = () => {
//     setFilters({
//       company: "",
//       category: "",
//       tags: "",
//       startDate: "",
//       endDate: "",
//       status: "",
//       vat: "",
//       projectType: "",
//     });
//     onReset();
//   };

//   return (
//     <div className="filter-modal-overlay">
//       <div className="filter-modal">
//         <div className="filter-header">
//           <LuFilter size={20} />
//           <h2>Filter Clients</h2>
//           <button className="close-btn" onClick={onClose}>
//             <IoCloseSharp />
//           </button>
//         </div>

//         <div className="filter-body">
//           <label>Company Name</label>
//           <input type="text" name="company" value={filters.company} onChange={handleChange} />

//           <label>Category</label>
//           <input type="text" name="category" value={filters.category} onChange={handleChange} />

//           <label>Tags</label>
//           <input type="text" name="tags" value={filters.tags} onChange={handleChange} />

//           <label>Date Created</label>
//           <div className="date-inputs">
//             <input type="date" name="startDate" value={filters.startDate} onChange={handleChange} />
//             <input type="date" name="endDate" value={filters.endDate} onChange={handleChange} />
//           </div>

//           <label>Status</label>
//           <input type="text" name="status" value={filters.status} onChange={handleChange} />

//           <label>VAT</label>
//           <input type="text" name="vat" value={filters.vat} onChange={handleChange} />

//           <label>Projects Type</label>
//           <select name="projectType" value={filters.projectType} onChange={handleChange}>
//             <option value="">Select Type</option>
//             <option value="Web Development">Web Development</option>
//             <option value="Design">Design</option>
//             <option value="Marketing">Marketing</option>
//           </select>
//         </div>

//         <div className="filter-footer">
//           <button className="reset-btn" onClick={handleReset}>Reset</button>
//           <button className="apply-btn" onClick={handleApply}>Apply Filter</button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default FilterClientsModal;

import React, { useState } from "react";
import Select from "react-select";
import "./FilterClients.css";
import { LuFilter } from "react-icons/lu";

const FilterClientsModal = ({ clients, onClose, onApply, onReset }) => {
  const [filters, setFilters] = useState({
    company: [],
    category: [],
    tags: [],
    status: [],
    vat: "",
    projectType: "",
    startDate: "",
    endDate: "",
  });

  const companyOptions = [...new Set(clients.map(c => c.company))].map(c => ({ value: c, label: c }));
  const categoryOptions = [...new Set(clients.map(c => c.category))].map(c => ({ value: c, label: c }));
  const statusOptions = [...new Set(clients.map(c => c.status))].map(c => ({ value: c, label: c }));
  const tagOptions = [...new Set(clients.flatMap(c => c.tags || []))].map(t => ({ value: t, label: t }));

  const handleApply = () => {
    onApply(filters);
    onClose();
  };

  const handleReset = () => {
    setFilters({
      company: [],
      category: [],
      tags: [],
      status: [],
      vat: "",
      projectType: "",
      startDate: "",
      endDate: "",
    });
    onReset();
  };

  return (
    <div className="filter-modal-overlay">
      <div className="filter-modal slide-in">
        <div className="filter-header">
          <LuFilter size={20} />
          <h2>Filter Clients</h2>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>

        <div className="filter-body">
          <label>Company Name</label>
          <Select
            isMulti
            options={companyOptions}
            value={filters.company}
            onChange={(val) => setFilters({ ...filters, company: val })}
            placeholder="Search company..."
          />

          <label>Category</label>
          <Select
            isMulti
            options={categoryOptions}
            value={filters.category}
            onChange={(val) => setFilters({ ...filters, category: val })}
            placeholder="Search category..."
          />

          <label>Tags</label>
          <Select
            isMulti
            options={tagOptions}
            value={filters.tags}
            onChange={(val) => setFilters({ ...filters, tags: val })}
            placeholder="Search tags..."
          />

          <label>Date Created</label>
          <div className="date-inputs">
            <input type="date" value={filters.startDate} onChange={(e) => setFilters({ ...filters, startDate: e.target.value })} />
            <input type="date" value={filters.endDate} onChange={(e) => setFilters({ ...filters, endDate: e.target.value })} />
          </div>

          <label>Status</label>
          <Select
            isMulti
            options={statusOptions}
            value={filters.status}
            onChange={(val) => setFilters({ ...filters, status: val })}
            placeholder="Search status..."
          />

          <label>VAT</label>
          <input type="text" value={filters.vat} onChange={(e) => setFilters({ ...filters, vat: e.target.value })} />

          <label>Projects Type</label>
          <select value={filters.projectType} onChange={(e) => setFilters({ ...filters, projectType: e.target.value })}>
            <option value="">Select Type</option>
            <option value="Web Development">Web Development</option>
            <option value="Design">Design</option>
            <option value="Marketing">Marketing</option>
          </select>
        </div>

        <div className="filter-footer">
          <button className="reset-btn" onClick={handleReset}>Reset</button>
          <button className="apply-btn" onClick={handleApply}>Apply Filter</button>
        </div>
      </div>
    </div>
  );
};

export default FilterClientsModal;

